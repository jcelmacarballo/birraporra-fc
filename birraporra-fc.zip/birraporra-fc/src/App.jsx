import { useState, useEffect, useRef } from "react";

// ═══════════════════════════════════════════════════════════════════════════
//  BIRRAPORRA FC — La porra dels teus colegues
//  v1.5 · Català · Combo Europa gratis · Reorganització nav · Sense torneig/robatori
// ═══════════════════════════════════════════════════════════════════════════

// ─────────────────────────── 1. CONFIG ────────────────────────────────────
const CFG = {
  ADMIN_PASS: "gol2024",
  ENTRY_EUR: 2.50, START_BIRRAS: 50, BIRRA_EUR: 0.05, BEER_EUR: 2.50,
  PRIZES: [0.40, 0.30, 0.20, 0.10],
  RACHA_N: 3, RACHA_BONUS: 15,
  SUPER_MULT: 1.5, EXACT_BONUS: 2, DOUBLE_BONUS: 0.20,
  JOKER_PER_WEEK: 1,
  EUROPA_BONUSES: { 3: 5, 4: 10, 5: 15 },
  CLASICO_ENTRY: 5, CLASICO_REQUIRED: 2,
  CHAT_LIMIT: 200,
  EUROPA_REQUIRED: 5,
  COIN_ENTRY: 5, COIN_MAX_DOUBLES: 3,
};

const C = {
  bg: "#0a0907", card: "#16110a", card2: "#1e1810", border: "#2e2618",
  gold: "#f5b800", amber: "#c88800", muted: "#80746a", txt: "#f5eed8",
  red: "#e03838", green: "#38b858", blue: "#5299d6", purple: "#a855f7",
  rose: "#f43f5e", cyan: "#22d3ee",
};

const LEAGUES = ["La Liga", "Champions League", "Premier League", "Serie A", "Bundesliga", "Ligue 1", "Mundial", "Altres"];
const AVATAR_EMOJIS = ["🍺", "⚽", "🔥", "🏆", "😈", "🎯", "👑", "💪", "🦁", "🐂", "🦅", "🐺", "⚡", "💀", "🤘", "🍀"];

// ─────────────────────────── 2. STORAGE & UTILS ───────────────────────────
const KEYS = {
  accounts: "bporra_v8_accounts",
  groups: "bporra_v8_groups",
  members: "bporra_v8_members",
  matches: "bporra_v8_matches",
  bets: "bporra_v8_bets",
  clasico: "bporra_v8_clasico",
  europa: "bporra_v8_europa",
  chats: "bporra_v8_chats",
  coinflips: "bporra_v8_coinflips",
};

async function dbGet(k) { try { const r = await window.storage.get(k, true); return r ? JSON.parse(r.value) : null; } catch { return null; } }
async function dbSet(k, v) { try { await window.storage.set(k, JSON.stringify(v), true); } catch {} }

const uid = () => Math.random().toString(36).slice(2, 9) + Date.now().toString(36);
const hash = s => { let h = 5381; for (let i = 0; i < s.length; i++) h = ((h << 5) + h) + s.charCodeAt(i); return String(h >>> 0); };
const fmtDate = s => !s ? "" : new Date(s).toLocaleDateString("ca-ES", { weekday: "short", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
const fmtTime = ts => new Date(ts).toLocaleTimeString("ca-ES", { hour: "2-digit", minute: "2-digit" });
const fmtChatDate = ts => {
  const d = new Date(ts);
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const dDay = new Date(d); dDay.setHours(0, 0, 0, 0);
  if (dDay.getTime() === today.getTime()) return fmtTime(ts);
  const yesterday = new Date(today); yesterday.setDate(today.getDate() - 1);
  if (dDay.getTime() === yesterday.getTime()) return `Ahir ${fmtTime(ts)}`;
  return d.toLocaleDateString("ca-ES", { day: "numeric", month: "short" }) + " " + fmtTime(ts);
};
const fmtEUR = n => (Math.round(n * 100) / 100).toFixed(2) + "€";
const eurToBeers = eur => Math.floor((eur / CFG.BEER_EUR) * 10) / 10;
const getOutcome = (h, a) => h > a ? "H" : h < a ? "A" : "D";
const scoreKey = (h, a) => `${h}-${a}`;
const daysSince = ts => !ts ? Infinity : Math.floor((Date.now() - ts) / 86400000);
const weekKey = (ts = Date.now()) => { const d = new Date(ts); d.setHours(0,0,0,0); const day = d.getDay() || 7; d.setDate(d.getDate() - day + 1); return d.toISOString().slice(0,10); };
const matchStarted = m => m.date && new Date(m.date).getTime() <= Date.now();
const canBet = m => m.status !== "finished" && !matchStarted(m);
const isMondayMorning = () => { const d = new Date(); return d.getDay() === 1 && d.getHours() >= 8 && d.getHours() < 13; };

function shareToWhatsApp(text) {
  const encoded = encodeURIComponent(text);
  window.open(`https://wa.me/?text=${encoded}`, "_blank");
}

// ─────────────────────────── 3. BETTING MATH ──────────────────────────────
function calcPayout(bet, match) {
  if (!match.result) return null;
  const winOutcome = getOutcome(match.result.home, match.result.away);
  const winScore = scoreKey(match.result.home, match.result.away);
  if (bet.outcome !== winOutcome) return 0;
  let cuota = match.cuotas[bet.outcome];
  if (match.superBono) cuota *= CFG.SUPER_MULT;
  let payout = bet.amount * cuota;
  if (bet.joker) payout *= 2;
  if (bet.exactScore && bet.exactScore === winScore) payout *= CFG.EXACT_BONUS;
  return Math.round(payout);
}
function settleBets(allBets, match) {
  return allBets.map(b => b.matchId !== match.id ? b : { ...b, payout: calcPayout(b, match), settled: true });
}

// ─────────────────────────── 4. STYLES & ATOMS ────────────────────────────
const sty = {
  btnPrimary: { background: C.gold, color: "#0c0900", border: "none", borderRadius: 10, padding: "14px 16px", fontFamily: "var(--pff)", fontWeight: 900, fontSize: 18, letterSpacing: 1, cursor: "pointer" },
  btnGhost: { background: C.card2, color: C.muted, border: "none", borderRadius: 10, padding: "14px 16px", fontFamily: "var(--pff)", fontWeight: 700, fontSize: 16, cursor: "pointer" },
  btnWA: { background: "#25d366", color: "#fff", border: "none", borderRadius: 8, padding: "8px 14px", fontFamily: "var(--pff)", fontWeight: 700, fontSize: 13, letterSpacing: 0.5, cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 6 },
  input: { padding: "12px 14px", background: C.bg, border: `1px solid ${C.border}`, borderRadius: 8, color: C.txt, fontSize: 15, outline: "none", width: "100%", fontFamily: "inherit" },
  label: { fontSize: 11, color: C.muted, fontFamily: "var(--pff)", letterSpacing: 1, display: "block", marginBottom: 4 },
  sectionH: { fontFamily: "var(--pff)", fontWeight: 800, fontSize: 13, color: C.gold, letterSpacing: 2, marginBottom: 12 },
  card: { background: C.card, borderRadius: 12, border: `1px solid ${C.border}`, padding: 14 },
};

function Chip({ children, color = C.muted, bg = C.card2, border }) {
  return <span style={{ background: bg, color, fontSize: 10, fontWeight: 700, padding: "3px 8px", borderRadius: 4, letterSpacing: 1, fontFamily: "var(--pff)", border: border ? `1px solid ${border}` : "none", whiteSpace: "nowrap" }}>{children}</span>;
}
const SuperChip = () => <Chip color={C.gold} bg="#3a1800" border={C.amber}>⚡ SÚPER BONUS</Chip>;
const EuropaChip = () => <Chip color={C.purple} bg="#1a0a2e" border="#5a2080">🌍 TOP 5 EUROPA</Chip>;
const JokerChip = () => <Chip color={C.blue} bg="#0a1a2e" border={C.blue}>🃏 JOKER ×2</Chip>;
const ClasicoChip = () => <Chip color={C.rose} bg="#2a0512" border={C.rose}>🏆 JACKPOT</Chip>;
const LockedChip = () => <Chip color={C.muted} bg={C.card2} border={C.border}>🔒 TANCAT</Chip>;

function Cuota({ value, big }) {
  return <span style={{ fontFamily: "var(--pff)", fontWeight: 900, fontSize: big ? 24 : 16, color: C.gold, lineHeight: 1 }}>×{Number(value).toFixed(2)}</span>;
}
function RedDot({ show }) {
  if (!show) return null;
  return <div style={{ position: "absolute", top: 8, right: 8, width: 10, height: 10, background: C.red, borderRadius: "50%", animation: "pulse 1.5s ease-in-out infinite" }} />;
}

export default function App() {
  const [account, setAccount] = useState(null);
  const [activeGroupId, setActiveGroupId] = useState(null);
  const [accounts, setAccounts] = useState([]);
  const [groups, setGroups] = useState([]);
  const [members, setMembers] = useState([]);
  const [matches, setMatches] = useState([]);
  const [bets, setBets] = useState([]);
  const [clasico, setClasico] = useState([]);
  const [europa, setEuropa] = useState([]);
  const [chats, setChats] = useState([]);
  const [coinflips, setCoinflips] = useState([]);
  const [tab, setTab] = useState("matches");
  const [newMatchForm, setNewMatchForm] = useState({ home: "", away: "", date: "", league: LEAGUES[0], h: 1.5, d: 3.0, a: 2.5 });
  const [betMatch, setBetMatch] = useState(null);
  const [showClasico, setShowClasico] = useState(false);
  const [showCoin, setShowCoin] = useState(false);
  const [showEuropa, setShowEuropa] = useState(false);
  const [showRules, setShowRules] = useState(false);
  const [showWeeklyModal, setShowWeeklyModal] = useState(false);
  const [showAdmin, setShowAdmin] = useState(false);
  const [adminMode, setAdminMode] = useState(false);
  const [showEmojiChange, setShowEmojiChange] = useState(false);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [toast, setToast] = useState(null);
  const [chatInput, setChatInput] = useState("");
  const chatEndRef = useRef(null);

  // Load data on mount
  useEffect(() => {
    (async () => {
      const [a, g, m, mt, b, cl, e, ch, co] = await Promise.all([
        dbGet(KEYS.accounts), dbGet(KEYS.groups), dbGet(KEYS.members), dbGet(KEYS.matches),
        dbGet(KEYS.bets), dbGet(KEYS.clasico), dbGet(KEYS.europa), dbGet(KEYS.chats), dbGet(KEYS.coinflips),
      ]);
      setAccounts(a || []);
      setGroups(g || []);
      setMembers(m || []);
      setMatches(mt || []);
      setBets(b || []);
      setClasico(cl || []);
      setEuropa(e || []);
      setChats(ch || []);
      setCoinflips(co || []);
    })();
  }, []);

  // Save on change
  useEffect(() => { dbSet(KEYS.accounts, accounts); }, [accounts]);
  useEffect(() => { dbSet(KEYS.groups, groups); }, [groups]);
  useEffect(() => { dbSet(KEYS.members, members); }, [members]);
  useEffect(() => { dbSet(KEYS.matches, matches); }, [matches]);
  useEffect(() => { dbSet(KEYS.bets, bets); }, [bets]);
  useEffect(() => { dbSet(KEYS.clasico, clasico); }, [clasico]);
  useEffect(() => { dbSet(KEYS.europa, europa); }, [europa]);
  useEffect(() => { dbSet(KEYS.chats, chats); }, [chats]);
  useEffect(() => { dbSet(KEYS.coinflips, coinflips); }, [coinflips]);

  const currentGroup = groups.find(g => g.id === activeGroupId);
  const member = members.find(m => m.accountId === account?.id && m.groupId === activeGroupId);

  const showToast = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  return (
    <div style={{ width: "100%", height: "100vh", maxWidth: 480, margin: "0 auto", background: C.bg, display: "flex", flexDirection: "column", position: "relative", overflowY: "auto", overflowX: "hidden" }}>
      {!account ? (
        <LoginScreen accounts={accounts} onCreateAccount={(name, emoji) => {
          const newAcc = { id: uid(), name, emoji, createdAt: Date.now() };
          setAccounts([...accounts, newAcc]);
          setAccount(newAcc);
        }} onSelectAccount={(acc) => setAccount(acc)} />
      ) : !activeGroupId ? (
        <GroupSelector groups={groups} onCreateGroup={(name) => {
          const newGroup = { id: uid(), name, createdAt: Date.now(), members: [], jackpot: 0 };
          setGroups([...groups, newGroup]);
          const newMember = { id: uid(), accountId: account.id, groupId: newGroup.id, birras: CFG.START_BIRRAS, stats: {}, joinedAt: Date.now() };
          setMembers([...members, newMember]);
          setActiveGroupId(newGroup.id);
        }} onSelectGroup={(groupId) => {
          if (!members.find(m => m.accountId === account.id && m.groupId === groupId)) {
            const newMember = { id: uid(), accountId: account.id, groupId, birras: CFG.START_BIRRAS, stats: {}, joinedAt: Date.now() };
            setMembers([...members, newMember]);
          }
          setActiveGroupId(groupId);
        }} />
      ) : (
        <>
          <div style={{ flex: 1, overflowY: "auto", paddingBottom: 70, padding: "0 12px" }}>
            {tab === "matches" && (
              <div style={{ paddingTop: 14 }}>
                <div style={sty.sectionH}>PARTITS</div>
                {matches.filter(m => m.groupId === activeGroupId).map(m => (
                  <div key={m.id} style={{ ...sty.card, marginBottom: 10, cursor: "pointer" }} onClick={() => canBet(m) && setBetMatch(m)}>
                    <div style={{ display: "flex", justifyContent: "space-between", fontSize: 14, fontWeight: 600, marginBottom: 8 }}>
                      <span>{m.home}</span>
                      <span style={{ color: C.gold }}>vs</span>
                      <span>{m.away}</span>
                    </div>
                    <div style={{ display: "flex", justifyContent: "space-around", fontSize: 12, color: C.muted, marginBottom: 8 }}>
                      <Cuota value={m.cuotas.H} /> <Cuota value={m.cuotas.D} /> <Cuota value={m.cuotas.A} />
                    </div>
                    {m.result && <div style={{ color: C.green, fontSize: 12, fontWeight: 700 }}>Result: {m.result.home}-{m.result.away}</div>}
                  </div>
                ))}
              </div>
            )}
            {tab === "ranking" && (
              <div style={{ paddingTop: 14 }}>
                <div style={sty.sectionH}>RANKING</div>
                {members.filter(m => m.groupId === activeGroupId).sort((a, b) => b.birras - a.birras).map((m, i) => {
                  const acc = accounts.find(a => a.id === m.accountId);
                  return (
                    <div key={m.id} style={{ ...sty.card, marginBottom: 8, display: "flex", alignItems: "center", gap: 10 }}>
                      <span style={{ fontSize: 20 }}>{i + 1}.</span>
                      <span style={{ fontSize: 24 }}>{acc?.emoji || "🍺"}</span>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontWeight: 600 }}>{acc?.name}</div>
                        <div style={{ fontSize: 12, color: C.muted }}>🍺 {Math.round(m.birras)}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
            {tab === "more" && (
              <div style={{ paddingTop: 14 }}>
                <div style={sty.sectionH}>PERFIL</div>
                <div style={{ ...sty.card, marginBottom: 14, textAlign: "center", padding: "20px 14px" }}>
                  <div style={{ fontSize: 48, marginBottom: 10 }}>{account.emoji || "🍺"}</div>
                  <div style={{ fontFamily: "var(--pff)", fontWeight: 800, fontSize: 24, color: C.txt }}>{account.name}</div>
                  <div style={{ fontSize: 12, color: C.muted, marginTop: 2 }}>Grup: {currentGroup?.name}</div>
                </div>
                <button onClick={() => { setAccount(null); setActiveGroupId(null); setTab("matches"); }} style={{ ...sty.btnPrimary, width: "100%" }}>Tancar sessió</button>
              </div>
            )}
          </div>

          {/* BOTTOM NAV */}
          <div style={{ position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 480, background: C.card, borderTop: `1px solid ${C.border}`, display: "flex", zIndex: 50 }}>
            {[
              { id: "matches", i: "🏟️", l: "PARTITS" },
              { id: "ranking", i: "📊", l: "RANKING" },
              { id: "more", i: "⋯", l: "MÉS" },
            ].map(t => (
              <button key={t.id} onClick={() => setTab(t.id)} style={{ flex: 1, padding: "8px 2px 6px", background: "none", border: "none", display: "flex", flexDirection: "column", alignItems: "center", gap: 2, cursor: "pointer", borderTop: `2px solid ${tab === t.id ? C.gold : "transparent"}`, position: "relative" }}>
                <span style={{ fontSize: 18 }}>{t.i}</span>
                <span style={{ fontSize: 8, fontWeight: 700, color: tab === t.id ? C.gold : C.muted, fontFamily: "var(--pff)", letterSpacing: 0.3 }}>{t.l}</span>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

function LoginScreen({ accounts, onCreateAccount, onSelectAccount }) {
  const [step, setStep] = useState("choose");
  const [name, setName] = useState("");
  const [emoji, setEmoji] = useState("🍺");

  return (
    <div style={{ padding: 20, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100vh" }}>
      <div style={{ fontSize: 64, marginBottom: 20 }}>🍺⚽</div>
      <h1 style={{ fontSize: 28, fontFamily: "var(--pff)", fontWeight: 900, marginBottom: 20, textAlign: "center" }}>BIRRAPORRA FC</h1>
      
      {step === "choose" && (
        <div style={{ width: "100%", maxWidth: 300 }}>
          {accounts.length > 0 && (
            <div style={{ marginBottom: 20 }}>
              <div style={{ fontSize: 12, color: C.muted, marginBottom: 10, fontFamily: "var(--pff)" }}>SELECCIONA COMPTE</div>
              {accounts.map(acc => (
                <button key={acc.id} onClick={() => onSelectAccount(acc)} style={{ width: "100%", ...sty.card, marginBottom: 10, display: "flex", alignItems: "center", gap: 10, cursor: "pointer" }}>
                  <span style={{ fontSize: 32 }}>{acc.emoji}</span>
                  <span style={{ fontWeight: 600 }}>{acc.name}</span>
                </button>
              ))}
              <div style={{ height: 1, background: C.border, marginBottom: 20 }} />
            </div>
          )}
          <button onClick={() => setStep("create")} style={{ ...sty.btnPrimary, width: "100%", marginBottom: 10 }}>+ CREAR COMPTE</button>
        </div>
      )}

      {step === "create" && (
        <div style={{ width: "100%", maxWidth: 300 }}>
          <div style={{ ...sty.card, marginBottom: 14 }}>
            <div style={sty.label}>NOM</div>
            <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="El teu nom" style={sty.input} />
          </div>
          <div style={{ ...sty.card, marginBottom: 20 }}>
            <div style={sty.label}>EMOJI</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 8 }}>
              {AVATAR_EMOJIS.map(e => (
                <button key={e} onClick={() => setEmoji(e)} style={{ fontSize: 28, padding: 8, background: emoji === e ? C.gold : C.card2, border: `2px solid ${emoji === e ? C.amber : "transparent"}`, borderRadius: 8, cursor: "pointer" }}>{e}</button>
              ))}
            </div>
          </div>
          <button onClick={() => { if (name) { onCreateAccount(name, emoji); setStep("choose"); setName(""); } }} style={{ ...sty.btnPrimary, width: "100%", marginBottom: 10 }}>CREAR</button>
          <button onClick={() => setStep("choose")} style={{ ...sty.btnGhost, width: "100%" }}>ENRERE</button>
        </div>
      )}
    </div>
  );
}

function GroupSelector({ groups, onCreateGroup, onSelectGroup }) {
  const [name, setName] = useState("");

  return (
    <div style={{ padding: 20, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100vh" }}>
      <div style={{ fontSize: 48, marginBottom: 20 }}>👥</div>
      <h2 style={{ fontSize: 22, fontFamily: "var(--pff)", fontWeight: 900, marginBottom: 20 }}>SELECCIONA GRUP</h2>
      
      <div style={{ width: "100%", maxWidth: 300 }}>
        {groups.length > 0 && (
          <div style={{ marginBottom: 20 }}>
            {groups.map(g => (
              <button key={g.id} onClick={() => onSelectGroup(g.id)} style={{ width: "100%", ...sty.card, marginBottom: 10, cursor: "pointer", fontWeight: 600 }}>
                {g.name}
              </button>
            ))}
            <div style={{ height: 1, background: C.border, marginBottom: 20 }} />
          </div>
        )}

        <div style={{ ...sty.card, marginBottom: 14 }}>
          <div style={sty.label}>CREAR NOU GRUP</div>
          <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Nom del grup" style={sty.input} />
        </div>
        <button onClick={() => { if (name) { onCreateGroup(name); setName(""); } }} style={{ ...sty.btnPrimary, width: "100%" }}>CREAR</button>
      </div>
    </div>
  );
}
